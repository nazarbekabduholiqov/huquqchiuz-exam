module.exports=async(req,res)=>{
 const password=req.headers["x-admin-password"];
 if(!process.env.ADMIN_PASSWORD||password!==process.env.ADMIN_PASSWORD)return res.status(401).json({error:"Admin paroli noto'g'ri"});
 if(req.method!=="GET")return res.status(405).json({error:"Method not allowed"});
 try{
  if(!process.env.GH_TOKEN||!process.env.GH_REPO)throw Error("GitHub sozlamalari topilmadi");
  const url=`https://api.github.com/repos/${process.env.GH_REPO}/contents/data/results.json`;
  const r=await fetch(url,{headers:{Authorization:`Bearer ${process.env.GH_TOKEN}`,Accept:"application/vnd.github+json","X-GitHub-Api-Version":"2022-11-28"}});
  if(r.status===404)return res.status(200).json({rows:[]});
  if(!r.ok)throw Error("GitHub'dan natijalar olinmadi");
  const d=await r.json();return res.status(200).json({rows:JSON.parse(Buffer.from(d.content,"base64").toString("utf8"))});
 }catch(e){console.error(e);return res.status(500).json({error:"Natijalarni yuklashda xatolik"});}
};