const OpenAI = require("openai");
const KEY = {1:"C",2:"A",3:"B",4:"D",5:"C",6:"B",7:"D",8:"A",9:"C",10:"B",11:"A",12:"D"};
const WRITTEN = {
  13:{answer:"1",accepted:["1","bir","bir oy","har oy","har oyda","har oyda bir marta","kamida bir oyda bir marta"]},
  14:{answer:"45",accepted:["45","45 kun","qirq besh","qirq besh kun"]},
  15:{answer:"225",accepted:["225","225 million","225 million so'm","ikki yuz yigirma besh","ikki yuz yigirma besh million"]}
};
const norm=s=>String(s??"").toLowerCase().replace(/[’‘`´]/g,"'").replace(/[^a-z0-9\u0400-\u04ff]/g,"").trim();
async function aiGrade(client,id,value,rule){
 const prompt=`Imtihon javobini qat'iy tekshir. Savol №${id}. Kutilgan javob: ${rule.answer}. Qabul qilinadigan variantlar: ${rule.accepted.join("; ")}. O'quvchi javobi: ${String(value).slice(0,300)}. Faqat mazmunan aynan teng javobni true deb bahola. Raqamli javob boshqa son bo'lsa, hech qachon true dema. Faqat {"correct":true} yoki {"correct":false} JSON qaytar.`;
 const out=await client.chat.completions.create({model:"gpt-4o-mini",temperature:0,response_format:{type:"json_object"},messages:[{role:"system",content:"You are a strict exam grader."},{role:"user",content:prompt}]});
 try{return JSON.parse(out.choices[0].message.content).correct===true;}catch{return false;}
}
async function githubGet(){
 const {GH_TOKEN,GH_REPO}=process.env;if(!GH_TOKEN||!GH_REPO)throw Error("GitHub sozlamalari topilmadi");
 const url=`https://api.github.com/repos/${GH_REPO}/contents/data/results.json`;
 const r=await fetch(url,{headers:{Authorization:`Bearer ${GH_TOKEN}`,Accept:"application/vnd.github+json","X-GitHub-Api-Version":"2022-11-28"}});
 if(r.status===404)return {url,sha:null,rows:[]};
 if(!r.ok)throw Error("GitHub faylini o'qib bo'lmadi");
 const d=await r.json();return {url,sha:d.sha,rows:JSON.parse(Buffer.from(d.content,"base64").toString("utf8"))};
}
async function githubSave(row){
 const state=await githubGet();state.rows.push(row);
 const content=Buffer.from(JSON.stringify(state.rows,null,2)).toString("base64");
 const r=await fetch(state.url,{method:"PUT",headers:{Authorization:`Bearer ${process.env.GH_TOKEN}`,Accept:"application/vnd.github+json","X-GitHub-Api-Version":"2022-11-28","Content-Type":"application/json"},body:JSON.stringify({message:`Add exam result: ${row.name}`,content,...(state.sha?{sha:state.sha}:{})})});
 if(!r.ok){const t=await r.text();throw Error("GitHub'ga saqlashda xatolik: "+t.slice(0,300));}
}
module.exports=async(req,res)=>{
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 try{
  const {name,group,answers={},started_at,duration_seconds,auto_submitted}=req.body||{};
  if(!name||String(name).trim().length<3)return res.status(400).json({error:"Ism-familiya kiritilmagan"});
  let correct=0;const detail={};const openai=process.env.OPENAI_API_KEY?new OpenAI({apiKey:process.env.OPENAI_API_KEY}):null;
  for(let i=1;i<=12;i++){const ok=String(answers[i]||"").toUpperCase().trim()===KEY[i];detail[i]={answer:answers[i]||"",correct:ok};if(ok)correct++;}
  for(let i=13;i<=15;i++){const v=String(answers[i]||"");const n=norm(v);let ok=WRITTEN[i].accepted.some(a=>norm(a)===n);if(!ok&&openai&&v.trim())ok=await aiGrade(openai,i,v,WRITTEN[i]);detail[i]={answer:v,correct:ok};if(ok)correct++;}
  const row={id:Date.now().toString(),name:String(name).trim(),group_name:String(group||"").trim(),score:correct,percent:Math.round(correct/15*100),answers:detail,duration_seconds:Number(duration_seconds)||0,auto_submitted:!!auto_submitted,started_at:started_at||null,created_at:new Date().toISOString()};
  await githubSave(row);return res.status(200).json({score:correct,correct,percent:row.percent});
 }catch(e){console.error(e);return res.status(500).json({error:"Natijani saqlashda xatolik. Admin sozlamalarini tekshiring."});}
};